
# Dra. Rafaela Sanvezzo - Site
Arquivos estáticos prontos para deploy no Vercel/Netlify/GitHub Pages.

- Abrir `index.html` para pré-visualizar localmente.
- Site pronto para upload no GitHub: criar repositório `drarafaelasanvezzo-site` e enviar estes arquivos.
